# frozen_string_literal: true

require_relative 'location'

Somewhere = Location.new('mx', 97_400)
Somewhere.wind_info
