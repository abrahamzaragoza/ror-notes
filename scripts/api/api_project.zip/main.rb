# frozen_string_literal: true

require_relative 'location'

somewhere = Location.new('mx', 97_400)
somewhere.wind_info
